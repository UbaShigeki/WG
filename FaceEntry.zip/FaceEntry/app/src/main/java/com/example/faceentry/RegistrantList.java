package com.example.faceentry;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Environment;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class RegistrantList extends AppCompatActivity {

    private final String dataFileName = "Feature_Name.dat"; // 社員番号と社員名の格納ファイル
    private final String employeeNoCode = "Feature_";       // 社員番号への付与文字
    ArrayList<String> employeeNo = new ArrayList<>();       // 社員番号
    ArrayList<String> employeeName = new ArrayList<>();     // 社員名

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registrant_list);

        // レイアウトから登録者数を取得
        TextView employeeNum = findViewById(R.id.employeeNum);
        // レイアウトからリストビューを取得
        ListView listView = findViewById(R.id.list_view);

        // Listデータの読み込み
        // 社員番号と社員名の読み込み
        if (!employeeDataRead()) {
            // 読み込む社員がいない場合
            Toast.makeText(this, "登録者情報がありません", Toast.LENGTH_SHORT).show();
            finish();       // リスト画面終了
            return;
        }

        // リストビューに表示する要素を設定
        ArrayList<ListItem> listItems = new ArrayList<>();
        for (int i = 0; i < employeeNo.size(); i++) {
            // リストアイテムに設定
            ListItem item = new ListItem(employeeNo.get(i), employeeName.get(i));
            // リストアイテムに追加
            listItems.add(item);
        }

        // 出力結果をリストビューに表示
        RegistrantListAdapter adapter = new RegistrantListAdapter(this, R.layout.list_item, listItems);
        listView.setAdapter(adapter);

        // 登録者数をリスト上部に表示
        employeeNum.setText("登録者数：" + employeeNo.size());
    }

    // 社員番号と社員名を読み込む
    private boolean employeeDataRead() {
        String filePath = Environment.getExternalStorageDirectory().getPath() + File.separator + Environment.DIRECTORY_PICTURES + File.separator + dataFileName;
        try{
            FileInputStream inputStream = new FileInputStream(filePath);
            if (inputStream != null) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                String lineBuffer;
                while ((lineBuffer = reader.readLine()) != null) {
                    if (lineBuffer != null) {
                        // 指定の文字があれば社員番号とみなす
                        if (lineBuffer.contains(employeeNoCode)) {
                            // 指定の文字を削って格納
                            employeeNo.add(lineBuffer.substring(employeeNoCode.length()));
                        }
                        // 指定の文字がなければ社員名とみなす
                        else {
                            // 社員名はそのまま格納
                            employeeName.add(lineBuffer);
                        }
                    } else {
                        break;
                    }
                }
                inputStream.close();
            }
        } catch (FileNotFoundException e) {
            System.out.println("ファイルが見つかりませんでした");
        } catch (IOException e) {
            System.out.println("社員データ読み込みでIOExceptionが発生しました");
        }
        // 誰も読み込まなかったらfalse
        if (employeeNo.size() <= 0) {
            return false;
        }
        return true;
    }
}