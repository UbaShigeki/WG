package com.example.faceentry;

public class ListItem {
    private String mEmployeeNo = null;
    private String mEmployeeName = null;

    /**
     * 空のコンストラクタ
     */
    public ListItem() {};

    /**
     * コンストラクタ
     * @param employeeNo 社員番号
     * @param employeeName 社員名
     */
    public ListItem(String employeeNo, String employeeName) {
        mEmployeeNo = employeeNo;
        mEmployeeName = employeeName;
    }

    /**
     * 社員番号を設定
     * @param employeeNo 社員番号
     */
    public void setEmployeeNo(String employeeNo) {
        mEmployeeNo = employeeNo;
    }

    /**
     * 社員名を設定
     * @param employeeName 社員名
     */
    public void setEmployeeName(String employeeName) {
        mEmployeeName = employeeName;
    }

    /**
     * 社員番号を取得
     * @return 社員番号
     */
    public String getEmployeeNo() {
        return mEmployeeNo;
    }

    /**
     * 社員名を取得
     * @return 社員名
     */
    public String getEmployeeName() {
        return mEmployeeName;
    }
}
